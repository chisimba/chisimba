PTViewer 2.8, based on V2.5 by Helmut Dersch.

More info at http://www.fsoft.it/panorama/ptviewer.htm

This zip file contains two different jar files.
The smaller one contains only the basic panorama viewer without any extensions.
The bigger one contains the panorama viewer with all extensions and it can be run 
as a standalone program too. Knows limitation: the integrated toolbar does not show up
if the viewer is run as a standalone program.

Fulvio Senore
fsenore@ica-net.it